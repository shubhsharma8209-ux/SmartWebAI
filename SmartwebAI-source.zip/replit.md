# SmartwebAI

A team workspace for organizing projects, access, and private project files.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server on its workflow-assigned port
- `pnpm --filter @workspace/smartwebai run dev` — run the SmartwebAI web app
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required services: PostgreSQL (`DATABASE_URL`), managed Clerk auth, and Replit App Storage.
- Clerk development keys are for preview only; configure production Clerk credentials before publishing.

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Web: React, Vite, Wouter, TanStack Query, Clerk
- File contents: Replit App Storage; file metadata and workspace data: PostgreSQL
- API build: esbuild bundle

## Where things live

- `artifacts/smartwebai/` — public site and signed-in workspace UI
- `artifacts/api-server/` — API routes, Clerk authentication, storage access checks
- `lib/api-spec/openapi.yaml` — API contract source of truth
- `lib/db/src/schema/` — Drizzle database schema
- `lib/api-client-react/` and `lib/api-zod/` — generated client hooks and validation schemas

## Architecture decisions

- Clerk owns account authentication; database membership rows store Clerk user IDs, not password hashes.
- Project file bytes are uploaded directly to private App Storage using short-lived signed URLs. The API stores metadata and checks workspace membership for every list, download, completion, and delete action.
- Use Drizzle in the existing shared database package; the supplied Prisma schema is a reference, not a reason to replace the existing database stack.

## Product

Phase 1 includes authentication, workspace membership and roles, project organization, invitations, and private project file uploads/downloads. Real-time editing, AI coding/document tools, and deployment are not implemented yet.

## User preferences

No standing preferences supplied.

## Gotchas

- Regenerate API hooks and Zod schemas after changing `lib/api-spec/openapi.yaml`.
- Keep Clerk proxy middleware before body parsing, and keep authenticated API routes behind the Clerk middleware.
- Use `pnpm --filter @workspace/db run push` only for development schema changes; do not point it at production.
- Invitation URLs are bearer links: anyone holding one can join with the invited role until expiry or revocation. Share them privately.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details

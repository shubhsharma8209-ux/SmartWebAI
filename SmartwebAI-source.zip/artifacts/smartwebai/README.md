# SmartwebAI source

This source package is part of the official SmartwebAI web application. It includes the web frontend, API service, database schema, and shared API packages in this workspace.

## Available functions

- Create an account or sign in.
- Create and switch between workspaces.
- Create projects and choose their workspace/private visibility.
- Invite teammates with a starting role, change member roles, remove members, and revoke invitations.
- Upload, list, download, and delete project files. Uploads are limited to 25 MB per file.

Real-time co-editing, AI coding/document assistance, and project deployment are not included in the current implementation.

## Run in Replit

The app relies on PostgreSQL, Replit-managed Clerk authentication, and Replit App Storage. Those services are configured outside this source archive; no credentials or environment-secret values are included.

Install workspace packages with `pnpm install`, then start both managed workflows:

- `pnpm --filter @workspace/api-server run dev`
- `pnpm --filter @workspace/smartwebai run dev`

The web app expects the API to be routed under `/api`, as configured by the included Replit artifact manifests. For local use outside Replit, configure an equivalent `/api` reverse proxy and the required database, authentication, and storage services.

Run `pnpm run typecheck` to check the workspace. If the OpenAPI contract changes, regenerate the shared API packages with `pnpm --filter @workspace/api-spec run codegen`.

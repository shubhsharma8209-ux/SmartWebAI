import { useEffect, useRef, useState, type ChangeEvent, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ClerkProvider, Show, SignIn, SignUp, useClerk, useUser } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import {
  Activity, ArrowDownRight, ArrowRight, ArrowUpRight, Box, Check, ChevronDown,
  CircleHelp, Code2, Copy, Download, FileText, FolderKanban, GitBranch, Globe2,
  KeyRound, LayoutDashboard, LockKeyhole, LogOut, MoreHorizontal, Plus, Search,
  Settings2, ShieldCheck, Sparkles, Trash2, Upload, Users, X, type LucideIcon,
} from 'lucide-react';
import {
  getDownloadProjectFileUrl, getGetDashboardQueryKey, getGetInvitationQueryKey,
  getHealthCheckQueryKey, getListInvitationsQueryKey, getListMembersQueryKey,
  getListProjectFilesQueryKey, getListProjectsQueryKey, getListWorkspacesQueryKey,
  useAcceptInvitation, useCompleteProjectFileUpload, useCreateInvitation,
  useCreateProject, useCreateWorkspace, useDeleteProject, useDeleteProjectFile,
  useGetDashboard, useGetInvitation, useHealthCheck, useListInvitations,
  useListMembers, useListProjectFiles, useListProjects, useListWorkspaces,
  useRemoveMember, useRequestProjectFileUpload, useRevokeInvitation,
  useUpdateMemberRole, useUpdateProject,
} from '@workspace/api-client-react';
import type { Role, Workspace, WorkspaceMember } from '@workspace/api-client-react';
import { Link, Redirect, Route, Switch, Router as WouterRouter, useLocation, useRoute } from 'wouter';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, refetchOnWindowFocus: false, staleTime: 20_000 } },
});
const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');

function stripBase(path: string) {
  return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || '/' : path;
}

const roleOptions: Role[] = ['ADMIN', 'DEVELOPER', 'DESIGNER', 'CONTRIBUTOR', 'VIEWER'];
const roleLabel = (role: Role) => role.charAt(0) + role.slice(1).toLowerCase();
const dateLabel = (value: string) => new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric', year: 'numeric' }).format(new Date(value));

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: '#285f51',
    colorForeground: '#253631',
    colorMutedForeground: '#687871',
    colorDanger: '#a34439',
    colorBackground: '#faf8f1',
    colorInput: '#fffdf7',
    colorInputForeground: '#253631',
    colorNeutral: '#d8d5c9',
    fontFamily: 'Manrope, sans-serif',
    borderRadius: '0.75rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-[#faf8f1] rounded-2xl w-[440px] max-w-full overflow-hidden border border-[#e4dfd3]',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-[#253631] font-bold tracking-tight',
    headerSubtitle: 'text-[#687871]',
    socialButtonsBlockButtonText: 'text-[#253631] font-semibold',
    formFieldLabel: 'text-[#344942] font-semibold',
    footerActionLink: 'text-[#285f51] font-bold',
    footerActionText: 'text-[#687871]',
    dividerText: 'text-[#687871]',
    identityPreviewEditButton: 'text-[#285f51]',
    formFieldSuccessText: 'text-[#285f51]',
    alertText: 'text-[#8e3c32]',
    logoBox: 'rounded-xl',
    logoImage: 'rounded-lg',
    socialButtonsBlockButton: 'border-[#d8d5c9] bg-[#fffdf7] hover:bg-[#f1eee5]',
    formButtonPrimary: 'bg-[#285f51] hover:bg-[#1f5044] text-white',
    formFieldInput: 'border-[#d8d5c9] bg-[#fffdf7] text-[#253631]',
    footerAction: 'text-[#687871]',
    dividerLine: 'bg-[#ded9cd]',
    alert: 'border-[#ecc4bb] bg-[#fff2ee]',
    otpCodeFieldInput: 'border-[#d8d5c9] bg-[#fffdf7]',
    formFieldRow: 'gap-2',
    main: 'gap-5',
  },
};

function Mark({ inverse = false }: { inverse?: boolean }) {
  return <span className={`brand-mark ${inverse ? 'brand-inverse' : ''}`} aria-hidden="true"><Code2 size={19} strokeWidth={2.5} /></span>;
}

function HomeRedirect() {
  return <><Show when="signed-in"><Redirect to="/user-portal" /></Show><Show when="signed-out"><Home /></Show></>;
}

function Home() {
  const health = useHealthCheck({ query: { queryKey: getHealthCheckQueryKey(), retry: false } });
  return (
    <div className="landing-page grain">
      <header className="landing-nav">
        <Link href="/" className="landing-brand" data-testid="link-home-brand"><Mark /><span>smartweb<span className="brand-ai">AI</span></span></Link>
        <nav aria-label="Main navigation" className="landing-nav-links">
          <a href="#how-it-works">How it works</a><a href="#principles">Principles</a>
          <Link href="/sign-in" className="nav-signin" data-testid="link-sign-in">Sign in <ArrowRight size={14} /></Link>
          <Link href="/sign-up" className="nav-cta" data-testid="link-sign-up">Create your workspace <ArrowUpRight size={15} /></Link>
        </nav>
      </header>
      <main>
        <section className="landing-hero hero-grid">
          <div className="hero-copy">
            <div className="status-kicker"><span className={`status-light ${health.isError ? 'offline' : ''}`} /> A calmer place to build together</div>
            <h1>Get the work<br />in <em>good shape.</em></h1>
            <p className="hero-description">A focused workspace for the people, plans, and projects behind your next great piece of software.</p>
            <div className="hero-actions"><Link href="/sign-up" className="button-primary" data-testid="button-start-workspace">Start a workspace <ArrowRight size={16} /></Link><a className="text-action" href="#how-it-works">See how it works <ArrowDownRight size={15} /></a></div>
            <div className="hero-proof"><span className="proof-lines"><i /><i /><i /></span><span>Made for the early, important work.</span></div>
          </div>
          <div className="hero-art" aria-label="SmartwebAI project workspace preview">
            <div className="artifact-window">
              <div className="window-top"><span className="window-lights"><i /><i /><i /></span><span className="window-label font-mono">FIELDNOTES / PROJECTS</span><MoreHorizontal size={17} /></div>
              <div className="workspace-preview">
                <div className="preview-sidebar"><div className="preview-logo"><Mark /> <b>fieldnotes</b></div><span className="preview-nav selected"><LayoutDashboard size={13} /> Overview</span><span className="preview-nav"><FolderKanban size={13} /> Projects</span><span className="preview-nav"><Users size={13} /> People</span><div className="preview-sidebar-foot"><span className="mini-avatar">FN</span><span>Fieldnotes Studio</span></div></div>
                <div className="preview-main"><div className="preview-label font-mono">MONDAY, 14 OCTOBER</div><h3>Good morning, team.</h3><p>Here's where the work stands.</p><div className="preview-metrics"><div><small>PROJECTS</small><b>04</b></div><div><small>PEOPLE</small><b>07</b></div></div><div className="preview-project-head"><b>In motion</b><small>VIEW ALL <ArrowRight size={10} /></small></div><div className="preview-project"><span className="project-symbol mint"><GitBranch size={14} /></span><span><b>Atlas / onboarding</b><small>Updated a little while ago</small></span><span className="project-dot" /></div><div className="preview-project"><span className="project-symbol gold"><Box size={14} /></span><span><b>Signal design system</b><small>Updated yesterday</small></span><span className="project-dot soft" /></div></div>
              </div>
              <div className="preview-note"><span className="note-pin" /><span>Space to think before you ship.</span><span className="font-mono">01 — 04</span></div>
            </div>
            <div className="floating-stamp"><span className="font-mono">PHASE 01</span><b>Make room<br />for good work.</b><Sparkles size={17} /></div>
            <div className="hero-orbit orbit-one" /><div className="hero-orbit orbit-two" />
          </div>
          <div className="hero-index font-mono"><span>01</span><span>—</span><span>WORKSPACE</span></div>
        </section>
        <section className="landing-manifesto" id="principles">
          <div className="manifesto-index eyebrow">A good beginning</div>
          <div><h2>Before the code<br />comes the <span>clarity.</span></h2><p>Every ambitious project starts as a tangle of people, ideas, and open questions. SmartwebAI gives that early work a home — without asking you to learn another sprawling tool.</p><Link href="/sign-up" className="manifesto-link">Bring your team in <ArrowRight size={15} /></Link></div>
          <div className="manifesto-quote"><span className="quote-mark">“</span><p>The best project spaces make the next step feel obvious.</p><span className="font-mono">A WORKING PRINCIPLE</span></div>
        </section>
        <section className="landing-steps" id="how-it-works">
          <div className="steps-heading"><span className="eyebrow">The first few good moves</span><h2>Start with a shared picture.</h2><p>No ceremony. Just the pieces your team needs to get moving.</p></div>
          <div className="steps-list">
            <article className="step-row"><span className="step-number font-mono">01</span><div className="step-icon"><Users size={19} /></div><div><h3>Gather your people</h3><p>Bring collaborators into one secure workspace. Give each person the access that fits their part.</p></div><ArrowUpRight className="step-arrow" size={18} /></article>
            <article className="step-row"><span className="step-number font-mono">02</span><div className="step-icon"><FolderKanban size={19} /></div><div><h3>Name the work</h3><p>Give every project a clear home, whether it's a private experiment or a shared team effort.</p></div><ArrowUpRight className="step-arrow" size={18} /></article>
            <article className="step-row"><span className="step-number font-mono">03</span><div className="step-icon"><GitBranch size={19} /></div><div><h3>Keep momentum visible</h3><p>See your active projects and workspace at a glance. Pick up where the conversation left off.</p></div><ArrowUpRight className="step-arrow" size={18} /></article>
          </div>
        </section>
        <section className="landing-boundary">
          <div className="boundary-orbit"><div className="boundary-core"><Code2 size={32} /></div><span className="boundary-ring ring-a" /><span className="boundary-ring ring-b" /><span className="boundary-node node-a" /><span className="boundary-node node-b" /></div>
          <div><span className="eyebrow">Built in thoughtful phases</span><h2>Useful today.<br /><em>Ready for what's next.</em></h2><p>SmartwebAI starts with project organization and team access. AI-assisted coding and deployment tools belong to a later phase — we won't pretend they're here before they are.</p><Link href="/sign-up" className="button-light">Make your first workspace <ArrowRight size={15} /></Link></div>
        </section>
        <footer className="landing-footer"><Link href="/" className="landing-brand"><Mark /><span>smartweb<span className="brand-ai">AI</span></span></Link><span>Room for the work that matters.</span><div><Link href="/sign-in">Sign in</Link><Link href="/sign-up">Create account</Link></div></footer>
      </main>
    </div>
  );
}

function SignInPage() {
  return <div className="auth-background auth-page"><div className="auth-side-note"><Link href="/" className="landing-brand"><Mark /><span>smartweb<span className="brand-ai">AI</span></span></Link><div><span className="eyebrow">A place to begin</span><h1>Your team’s<br /><em>workbench.</em></h1><p>Projects, people, and a clear view of what comes next.</p></div><span className="font-mono auth-caption">SECURE COLLABORATION / PHASE 01</span></div><div className="auth-panel"><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} /></div></div>;
}
function SignUpPage() {
  return <div className="auth-background auth-page"><div className="auth-side-note"><Link href="/" className="landing-brand"><Mark /><span>smartweb<span className="brand-ai">AI</span></span></Link><div><span className="eyebrow">Start something good</span><h1>Make room<br />to <em>build.</em></h1><p>Create your account and give your team's next project a place to take shape.</p></div><span className="font-mono auth-caption">YOUR WORK, IN GOOD COMPANY</span></div><div className="auth-panel"><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} /></div></div>;
}

function AppSidebar({ workspace, section, onSection }: { workspace?: Workspace; section: string; onSection: (v: string) => void }) {
  const sections: { id: string; label: string; icon: LucideIcon }[] = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'projects', label: 'Projects', icon: FolderKanban },
    { id: 'people', label: 'People & access', icon: Users },
  ];
  return <aside className="sidebar">
    <Link href="/" className="sidebar-brand" data-testid="link-sidebar-brand"><Mark /><span className="side-brand-copy">smartweb<span className="brand-ai">AI</span><small>TEAM WORKSPACE</small></span></Link>
    <div className="workspace-label">CURRENT WORKSPACE</div>
    <div className="workspace-switch"><span className="workspace-avatar">{workspace?.name?.slice(0, 1).toUpperCase() || 'S'}</span><span>{workspace?.name || 'Your workspaces'}<small>{workspace ? roleLabel(workspace.role) : 'Choose a workspace'}</small></span><ChevronDown size={14} /></div>
    <div className="side-section-label">WORKSPACE</div>
    <nav className="sidebar-nav" aria-label="Workspace navigation">
      {sections.map(({ id, label, icon: Icon }) => <button type="button" key={id} className={`nav-link ${section === id ? 'active' : ''}`} onClick={() => onSection(id)} data-testid={`nav-${id}`}><Icon size={16} /><span>{label}</span>{id === 'projects' && workspace?.projectCount ? <small className="nav-count">{workspace.projectCount}</small> : null}</button>)}
    </nav>
    <div className="sidebar-later"><div className="later-icon"><Sparkles size={15} /></div><div><b>More ways to build</b><p>AI coding and deployment are planned for a later phase.</p></div></div>
    <div className="sidebar-foot"><ShieldCheck size={14} /><span>Private by design</span><CircleHelp size={14} className="help-icon" /></div>
  </aside>;
}

function TopBar({ title }: { title: string }) {
  const { signOut } = useClerk();
  const { user } = useUser();
  const initial = user?.firstName?.[0] || user?.primaryEmailAddress?.emailAddress?.[0] || 'U';
  return <header className="topbar"><div className="crumb"><span>Workspace</span><span className="crumb-slash">/</span><b>{title}</b></div><div className="topbar-actions"><button className="top-icon" onClick={() => window.alert('SmartwebAI Phase 01 helps your team organize workspaces, projects, and access. AI coding and deployment tools are planned for a later phase.')} aria-label="Help and guidance" title="Help and guidance" data-testid="button-help"><CircleHelp size={17} /></button><span className="top-separator" /><div className="profile-chip"><span className="profile-avatar">{initial.toUpperCase()}</span><span className="profile-name">{user?.firstName || 'Your account'}</span><button className="signout-icon" onClick={() => signOut({ redirectUrl: basePath || '/' })} aria-label="Sign out" title="Sign out" data-testid="button-sign-out"><LogOut size={15} /></button></div></div></header>;
}

function SkeletonPanel() {
  return <div className="panel loading-panel" aria-label="Loading workspace"><div className="skeleton" style={{ width: 130, height: 12 }} /><div className="skeleton" style={{ width: '55%', height: 28, marginTop: 20 }} /><div className="skeleton" style={{ width: '80%', height: 12, marginTop: 11 }} /><div className="skeleton" style={{ width: '100%', height: 88, marginTop: 30 }} /></div>;
}

function EmptyState({ icon: Icon, title, detail, action }: { icon: LucideIcon; title: string; detail: string; action?: ReactNode }) {
  return <div className="empty-state"><span className="empty-icon"><Icon size={20} /></span><h3>{title}</h3><p>{detail}</p>{action}</div>;
}

function WorkspacePortal() {
  const [section, setSection] = useState('overview');
  const [selectedId, setSelectedId] = useState('');
  const [modal, setModal] = useState<'workspace' | 'project' | 'invite' | null>(null);
  const [workspaceName, setWorkspaceName] = useState('');
  const [projectName, setProjectName] = useState('');
  const [projectPrivate, setProjectPrivate] = useState(true);
  const [inviteRole, setInviteRole] = useState<Role>('DEVELOPER');
  const [freshInvite, setFreshInvite] = useState<string | null>(null);
  const [feedback, setFeedback] = useState('');
  const client = useQueryClient();
  const dashboard = useGetDashboard({ query: { queryKey: getGetDashboardQueryKey() } });
  const workspaces = useListWorkspaces({ query: { queryKey: getListWorkspacesQueryKey() } });
  const createWorkspace = useCreateWorkspace();
  const createProject = useCreateProject();
  const updateProject = useUpdateProject();
  const deleteProject = useDeleteProject();
  const createInvitation = useCreateInvitation();
  const revokeInvitation = useRevokeInvitation();
  const updateRole = useUpdateMemberRole();
  const removeMember = useRemoveMember();
  const workspaceList = workspaces.data ?? [];
  const activeWorkspace = workspaceList.find(w => w.id === selectedId) ?? workspaceList[0];
  const workspaceId = activeWorkspace?.id ?? '';
  const projects = useListProjects(workspaceId, { query: { enabled: !!workspaceId, queryKey: getListProjectsQueryKey(workspaceId) } });
  const members = useListMembers(workspaceId, { query: { enabled: !!workspaceId, queryKey: getListMembersQueryKey(workspaceId) } });
  const invitations = useListInvitations(workspaceId, { query: { enabled: !!workspaceId, queryKey: getListInvitationsQueryKey(workspaceId) } });
  const pageTitle = section === 'overview' ? 'Overview' : section === 'projects' ? 'Projects' : 'People & access';

  useEffect(() => {
    if (!feedback) return;
    const timeout = window.setTimeout(() => setFeedback(''), 3400);
    return () => window.clearTimeout(timeout);
  }, [feedback]);

  const invalidateWorkspace = () => {
    void client.invalidateQueries({ queryKey: getListWorkspacesQueryKey() });
    void client.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
    if (workspaceId) {
      void client.invalidateQueries({ queryKey: getListProjectsQueryKey(workspaceId) });
      void client.invalidateQueries({ queryKey: getListMembersQueryKey(workspaceId) });
      void client.invalidateQueries({ queryKey: getListInvitationsQueryKey(workspaceId) });
    }
  };

  function submitWorkspace(event: FormEvent) {
    event.preventDefault();
    if (!workspaceName.trim()) return;
    createWorkspace.mutate({ data: { name: workspaceName.trim() } }, {
      onSuccess: created => {
        setSelectedId(created.id); setWorkspaceName(''); setModal(null); setFeedback('Workspace created. Make it yours.');
        invalidateWorkspace();
      },
      onError: () => setFeedback('Could not create workspace. Please try again.'),
    });
  }
  function submitProject(event: FormEvent) {
    event.preventDefault();
    if (!projectName.trim() || !workspaceId) return;
    createProject.mutate({ workspaceId, data: { name: projectName.trim(), isPrivate: projectPrivate } }, {
      onSuccess: () => { setProjectName(''); setModal(null); setFeedback('Project added to your workspace.'); invalidateWorkspace(); },
      onError: () => setFeedback('Could not create project. Please try again.'),
    });
  }
  function submitInvitation(event: FormEvent) {
    event.preventDefault();
    if (!workspaceId) return;
    createInvitation.mutate({ workspaceId, data: { role: inviteRole } }, {
      onSuccess: result => { setFreshInvite(`${window.location.origin}${basePath}/invite/${result.token}`); invalidateWorkspace(); },
      onError: () => setFeedback('Could not create an invite. Check your access and try again.'),
    });
  }
  function copyInvite() {
    if (!freshInvite) return;
    void navigator.clipboard.writeText(freshInvite).then(() => setFeedback('Invite link copied. Share it only with the person you intend to invite.')).catch(() => setFeedback('Copy failed. Select and copy the invitation link.'));
  }
  function renameProject(projectId: string, currentName: string) {
    const name = window.prompt('Give this project a new name', currentName);
    if (!name?.trim() || name.trim() === currentName) return;
    updateProject.mutate({ projectId, data: { name: name.trim() } }, { onSuccess: () => { setFeedback('Project name updated.'); invalidateWorkspace(); }, onError: () => setFeedback('Could not update this project.') });
  }
  function confirmDelete(projectId: string, name: string) {
    if (!window.confirm(`Delete “${name}”? This cannot be undone.`)) return;
    deleteProject.mutate({ projectId }, { onSuccess: () => { setFeedback('Project removed.'); invalidateWorkspace(); }, onError: () => setFeedback('Could not delete this project.') });
  }
  function changeMemberRole(member: WorkspaceMember, role: Role) {
    updateRole.mutate({ workspaceId, memberId: member.id, data: { role } }, { onSuccess: invalidateWorkspace, onError: () => setFeedback('Could not change this member’s role.') });
  }
  function kickMember(member: WorkspaceMember) {
    if (!window.confirm('Remove this person from the workspace?')) return;
    removeMember.mutate({ workspaceId, memberId: member.id }, { onSuccess: () => { setFeedback('Member removed.'); invalidateWorkspace(); }, onError: () => setFeedback('Could not remove this member.') });
  }
  function revokeInvite(id: string) {
    if (!window.confirm('Revoke this invitation? Its link will stop working.')) return;
    revokeInvitation.mutate({ workspaceId, invitationId: id }, { onSuccess: () => { setFeedback('Invitation revoked.'); invalidateWorkspace(); }, onError: () => setFeedback('Could not revoke this invite.') });
  }

  const pageError = dashboard.isError || workspaces.isError;
  if (dashboard.isLoading || workspaces.isLoading) return <div className="app-shell"><AppSidebar section={section} onSection={setSection} /><div className="content-area"><TopBar title="Overview" /><main className="main-content"><div className="skeleton" style={{ width: 180, height: 12 }} /><div className="skeleton" style={{ width: 310, maxWidth: '80%', height: 38, marginTop: 18 }} /><div className="skeleton" style={{ width: '100%', height: 116, marginTop: 35 }} /><SkeletonPanel /></main></div></div>;

  if (pageError) return <div className="app-shell"><AppSidebar section={section} onSection={setSection} /><div className="content-area"><TopBar title="Overview" /><main className="main-content"><div className="error-box"><h2>Workspace data didn’t arrive.</h2><p>We couldn’t load your workspaces right now. Your work is untouched — try again in a moment.</p><button className="button-primary" onClick={() => { void dashboard.refetch(); void workspaces.refetch(); }} data-testid="button-retry-dashboard">Try again</button></div></main></div></div>;

  return <div className="app-shell">
    <AppSidebar workspace={activeWorkspace} section={section} onSection={setSection} />
    <div className="content-area"><TopBar title={pageTitle} />
      <main className="main-content page-enter">
        <div className="page-heading-row"><div><div className="eyebrow">{new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}</div><h1>{section === 'overview' ? 'A clear view of the work.' : section === 'projects' ? 'Projects, in focus.' : 'The people behind it.'}</h1><p>{section === 'overview' ? 'Your workspace, team, and the projects in motion.' : section === 'projects' ? 'Keep each effort named, organized, and easy to find.' : 'Manage who can join and what they can do.'}</p></div>
          <div className="heading-actions">{workspaceList.length > 0 && <label className="workspace-select-wrap"><span className="sr-only">Select workspace</span><select className="workspace-select" value={activeWorkspace?.id || ''} onChange={e => setSelectedId(e.target.value)} data-testid="select-workspace">{workspaceList.map(w => <option key={w.id} value={w.id}>{w.name}</option>)}</select><ChevronDown size={14} /></label>}<button className="button-primary" onClick={() => setModal(section === 'projects' ? 'project' : section === 'people' ? 'invite' : 'workspace')} disabled={section !== 'overview' && !activeWorkspace} data-testid="button-primary-action"><Plus size={16} />{section === 'projects' ? 'New project' : section === 'people' ? 'Invite people' : 'New workspace'}</button></div>
        </div>
        {feedback && <div className="toast-message" role="status" data-testid="status-feedback"><Check size={15} />{feedback}<button onClick={() => setFeedback('')} aria-label="Dismiss message"><X size={14} /></button></div>}
        {!activeWorkspace ? <div className="first-workspace"><div className="first-workspace-art"><div className="first-orbit" /><Box size={32} /></div><span className="eyebrow">A fresh start</span><h2>Give your team a place to land.</h2><p>Create a workspace to gather people and organize your first project. It only takes a moment.</p><button className="button-primary" onClick={() => setModal('workspace')} data-testid="button-create-first-workspace"><Plus size={16} /> Create your first workspace</button></div> : <>
          {section === 'overview' && <OverviewSection activeWorkspace={activeWorkspace} workspaceList={workspaceList} dashboard={dashboard.data} projects={projects.data} projectsQuery={projects} setSection={setSection} openProject={() => setModal('project')} openWorkspace={() => setModal('workspace')} />}
          {section === 'projects' && <ProjectsSection projects={projects.data} query={projects} canUpload={activeWorkspace.role !== 'VIEWER'} openProject={() => setModal('project')} renameProject={renameProject} deleteProject={confirmDelete} setPrivacy={(id, isPrivate) => updateProject.mutate({ projectId: id, data: { isPrivate } }, { onSuccess: () => { setFeedback('Project visibility updated.'); invalidateWorkspace(); }, onError: () => setFeedback('Could not update project visibility.') })} />}
          {section === 'people' && <PeopleSection workspace={activeWorkspace} members={members.data} membersQuery={members} invitations={invitations.data} invitationsQuery={invitations} openInvite={() => { setFreshInvite(null); setModal('invite'); }} changeRole={changeMemberRole} removeMember={kickMember} revokeInvite={revokeInvite} />}
        </>}
      </main>
    </div>
    {modal && <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && setModal(null)}>
      {modal === 'workspace' && <div className="modal-card" role="dialog" aria-modal="true" aria-labelledby="workspace-modal-title"><button className="modal-close" onClick={() => setModal(null)} aria-label="Close" data-testid="button-close-modal"><X size={17} /></button><div className="eyebrow">New workspace</div><h2 id="workspace-modal-title">Start with a name.</h2><p>Keep it recognizable to the people you’ll invite.</p><form onSubmit={submitWorkspace}><label className="field-label" htmlFor="workspace-name">Workspace name</label><input id="workspace-name" className="input-field" autoFocus maxLength={80} placeholder="e.g. Northstar Studio" value={workspaceName} onChange={e => setWorkspaceName(e.target.value)} data-testid="input-workspace-name" /><div className="modal-actions"><button type="button" className="button-quiet" onClick={() => setModal(null)}>Cancel</button><button type="submit" className="button-primary" disabled={!workspaceName.trim() || createWorkspace.isPending} data-testid="button-submit-workspace">{createWorkspace.isPending ? 'Creating…' : 'Create workspace'} <ArrowRight size={15} /></button></div></form></div>}
      {modal === 'project' && <div className="modal-card" role="dialog" aria-modal="true" aria-labelledby="project-modal-title"><button className="modal-close" onClick={() => setModal(null)} aria-label="Close"><X size={17} /></button><div className="eyebrow">New project · {activeWorkspace?.name}</div><h2 id="project-modal-title">What are you working on?</h2><p>Give this project a clear name. You can change it later.</p><form onSubmit={submitProject}><label className="field-label" htmlFor="project-name">Project name</label><input id="project-name" className="input-field" autoFocus maxLength={100} placeholder="e.g. Atlas onboarding" value={projectName} onChange={e => setProjectName(e.target.value)} data-testid="input-project-name" /><label className="privacy-choice"><input type="checkbox" checked={projectPrivate} onChange={e => setProjectPrivate(e.target.checked)} data-testid="checkbox-project-private" /><span className="privacy-icon"><LockKeyhole size={15} /></span><span><b>Private project</b><small>Only invited workspace members can access it.</small></span></label><div className="modal-actions"><button type="button" className="button-quiet" onClick={() => setModal(null)}>Cancel</button><button type="submit" className="button-primary" disabled={!projectName.trim() || createProject.isPending} data-testid="button-submit-project">{createProject.isPending ? 'Creating…' : 'Create project'} <ArrowRight size={15} /></button></div></form></div>}
      {modal === 'invite' && <div className="modal-card" role="dialog" aria-modal="true" aria-labelledby="invite-modal-title"><button className="modal-close" onClick={() => setModal(null)} aria-label="Close"><X size={17} /></button><div className="eyebrow">Share access · {activeWorkspace?.name}</div><h2 id="invite-modal-title">{freshInvite ? 'A link for your teammate.' : 'Bring someone in.'}</h2><p>{freshInvite ? 'This bearer link can be used by anyone who has it to request to join until it expires or is revoked. Share it privately.' : 'Choose the role they’ll start with. You can change access later.'}</p>{freshInvite ? <><div className="invite-link-box"><KeyRound size={15} /><span>{freshInvite}</span></div><div className="modal-actions"><button className="button-quiet" onClick={() => { setModal(null); setFreshInvite(null); }}>Done</button><button className="button-primary" onClick={copyInvite} data-testid="button-copy-invite"><Copy size={15} /> Copy link</button></div></> : <form onSubmit={submitInvitation}><label className="field-label" htmlFor="invite-role">Starting role</label><select id="invite-role" className="input-field" value={inviteRole} onChange={e => setInviteRole(e.target.value as Role)} data-testid="select-invite-role">{roleOptions.map(role => <option key={role} value={role}>{roleLabel(role)}</option>)}</select><div className="invite-caution"><ShieldCheck size={15} /><span>Anyone with the generated link can request to join. Only share it with someone you trust.</span></div><div className="modal-actions"><button type="button" className="button-quiet" onClick={() => setModal(null)}>Cancel</button><button type="submit" className="button-primary" disabled={createInvitation.isPending} data-testid="button-create-invite">{createInvitation.isPending ? 'Creating…' : 'Create invite link'} <ArrowRight size={15} /></button></div></form>}</div>}
    </div>}
  </div>;
}

function OverviewSection({ activeWorkspace, workspaceList, dashboard, projects, projectsQuery, setSection, openProject, openWorkspace }: {
  activeWorkspace: Workspace; workspaceList: Workspace[]; dashboard?: { workspaceCount: number; projectCount: number; memberCount: number; recentProjects: { id: string; workspaceId: string; name: string; isPrivate: boolean; updatedAt: string }[] };
  projects?: { id: string; workspaceId: string; name: string; isPrivate: boolean; updatedAt: string }[]; projectsQuery: ReturnType<typeof useListProjects>;
  setSection: (v: string) => void; openProject: () => void; openWorkspace: () => void;
}) {
  const stats = [{ label: 'Workspaces', value: dashboard?.workspaceCount ?? workspaceList.length, icon: Box, trend: 'Your shared spaces' }, { label: 'Projects', value: dashboard?.projectCount ?? activeWorkspace.projectCount, icon: FolderKanban, trend: 'Ideas taking shape' }, { label: 'People', value: dashboard?.memberCount ?? activeWorkspace.memberCount, icon: Users, trend: 'Across your teams' }];
  const recent = projects?.slice().sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()).slice(0, 4) ?? dashboard?.recentProjects?.filter(p => p.workspaceId === activeWorkspace.id).slice(0, 4) ?? [];
  return <div className="portal-layout">
    <div className="portal-main-column">
      <section className="welcome-panel"><div className="welcome-pattern"><span /><span /><span /></div><div className="welcome-copy"><span className="welcome-kicker"><Activity size={13} /> YOUR WORKSPACE IS READY</span><h2>Keep the important<br />work <em>in view.</em></h2><p>Everything starts with a clear picture of the team and what you’re making.</p></div><div className="welcome-bottom"><span className="welcome-space"><i />{activeWorkspace.name}</span><button onClick={() => setSection('projects')} className="welcome-link" data-testid="button-view-projects">Open projects <ArrowRight size={14} /></button></div></section>
      <div className="metrics-row">{stats.map(({ label, value, icon: Icon, trend }) => <div className="metric-card" key={label} data-testid={`metric-${label.toLowerCase()}`}><span className="metric-icon"><Icon size={16} /></span><span className="metric-label">{label}</span><b>{value}</b><small>{trend}</small></div>)}</div>
      <section className="section-block"><div className="section-header"><div><span className="eyebrow">Recently in motion</span><h2>Projects</h2></div><button className="text-link" onClick={() => setSection('projects')} data-testid="button-see-all-projects">All projects <ArrowRight size={14} /></button></div>
        {projectsQuery.isLoading ? <div className="project-skeleton"><div className="skeleton" /><div className="skeleton" /></div> : projectsQuery.isError ? <div className="inline-error">Projects couldn’t load. <button onClick={() => void projectsQuery.refetch()}>Try again</button></div> : recent.length === 0 ? <EmptyState icon={FolderKanban} title="A project gives the work a home." detail="Create one to start collecting plans, people, and next steps." action={<button className="button-primary" onClick={openProject} data-testid="button-empty-create-project"><Plus size={15} /> Create your first project</button>} /> : <div className="recent-project-list">{recent.map(project => <div className="recent-project-row" key={project.id} data-testid={`recent-project-${project.id}`}><span className={`project-symbol ${project.isPrivate ? 'mint' : 'gold'}`}>{project.isPrivate ? <LockKeyhole size={15} /> : <Globe2 size={15} />}</span><span className="recent-project-info"><b>{project.name}</b><small><span className="project-visibility">{project.isPrivate ? 'Private' : 'Workspace'}</span><span className="row-separator">·</span>Updated {dateLabel(project.updatedAt)}</small></span><ArrowUpRight className="recent-arrow" size={16} /></div>)}</div>}
      </section>
    </div>
    <aside className="portal-side-column">
      <section className="side-card workspace-card"><div className="side-card-heading"><span className="eyebrow">Your workspace</span><Settings2 size={15} /></div><div className="workspace-card-main"><div className="workspace-identity">{activeWorkspace.name.slice(0, 1).toUpperCase()}</div><div><b>{activeWorkspace.name}</b><small>Created {dateLabel(activeWorkspace.createdAt)}</small></div></div><div className="workspace-facts"><div><span>Your role</span><b>{roleLabel(activeWorkspace.role)}</b></div><div><span>Members</span><b>{activeWorkspace.memberCount}</b></div></div><button className="side-card-link" onClick={() => setSection('people')} data-testid="button-manage-people">Manage people <ArrowRight size={14} /></button></section>
      <section className="side-card quick-card"><span className="eyebrow">Quick actions</span><button onClick={openProject} data-testid="button-quick-project"><span><Plus size={15} /></span><b>Start a project</b><ArrowUpRight size={14} /></button><button onClick={openWorkspace} data-testid="button-quick-workspace"><span><Box size={15} /></span><b>New workspace</b><ArrowUpRight size={14} /></button></section>
      <section className="later-card"><div className="later-card-icon"><Sparkles size={16} /></div><div><span className="eyebrow">A note on what’s next</span><p>AI-assisted coding and deployment are planned for a future phase. Today, keep the foundations clear.</p></div></section>
    </aside>
  </div>;
}

function ProjectsSection({ projects, query, canUpload, openProject, renameProject, deleteProject, setPrivacy }: { projects?: { id: string; name: string; isPrivate: boolean; createdAt: string; updatedAt: string }[]; query: ReturnType<typeof useListProjects>; canUpload: boolean; openProject: () => void; renameProject: (id: string, name: string) => void; deleteProject: (id: string, name: string) => void; setPrivacy: (id: string, isPrivate: boolean) => void }) {
  if (query.isLoading) return <div className="project-card-grid">{[1, 2, 3].map(i => <SkeletonPanel key={i} />)}</div>;
  if (query.isError) return <div className="error-box"><h3>Projects couldn’t load.</h3><p>Try again to refresh this workspace.</p><button className="button-primary" onClick={() => void query.refetch()}>Retry</button></div>;
  if (!projects?.length) return <EmptyState icon={FolderKanban} title="No projects here yet." detail="Start a project to give your team's next effort its own clear place." action={<button className="button-primary" onClick={openProject}><Plus size={15} /> Create a project</button>} />;
   return <div className="project-page"><div className="project-page-toolbar"><div className="search-box"><Search size={15} /><span>{projects.length} {projects.length === 1 ? 'project' : 'projects'} in this workspace</span></div></div><div className="project-card-grid">{projects.map((p, i) => <article className="project-card" key={p.id} data-testid={`card-project-${p.id}`}><div className="project-card-top"><span className={`project-symbol ${i % 2 ? 'gold' : 'mint'}`}>{p.isPrivate ? <LockKeyhole size={16} /> : <Globe2 size={16} />}</span><button className="project-more" aria-label={`Rename ${p.name}`} title="Rename project" onClick={() => renameProject(p.id, p.name)} data-testid={`button-edit-project-${p.id}`}><MoreHorizontal size={18} /></button></div><h3>{p.name}</h3><p>{p.isPrivate ? 'Private to workspace members' : 'Visible to workspace members'}</p><div className="project-card-bottom"><span className={`visibility-pill ${p.isPrivate ? 'private' : 'public'}`}>{p.isPrivate ? <LockKeyhole size={11} /> : <Globe2 size={11} />}{p.isPrivate ? 'Private' : 'Workspace'}</span><span>Updated {dateLabel(p.updatedAt)}</span></div><div className="project-card-actions"><button onClick={() => renameProject(p.id, p.name)} data-testid={`button-rename-project-${p.id}`}>Rename</button><button onClick={() => setPrivacy(p.id, !p.isPrivate)} data-testid={`button-visibility-project-${p.id}`}>{p.isPrivate ? 'Make workspace-visible' : 'Make private'}</button><button onClick={() => deleteProject(p.id, p.name)} data-testid={`button-delete-project-${p.id}`}>Delete</button></div><ProjectFiles projectId={p.id} canUpload={canUpload} /></article>)}</div></div>;
}

function ProjectFiles({ projectId, canUpload }: { projectId: string; canUpload: boolean }) {
  const client = useQueryClient();
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [uploading, setUploading] = useState(false);
  const [notice, setNotice] = useState('');
  const files = useListProjectFiles(projectId, {
    query: { queryKey: getListProjectFilesQueryKey(projectId) },
  });
  const requestUpload = useRequestProjectFileUpload();
  const completeUpload = useCompleteProjectFileUpload();
  const deleteFile = useDeleteProjectFile();

  async function addFiles(event: ChangeEvent<HTMLInputElement>) {
    const selected = Array.from(event.currentTarget.files ?? []);
    event.currentTarget.value = '';
    if (selected.length === 0) return;
    setUploading(true);
    setNotice('');
    for (const file of selected) {
      if (file.size < 1 || file.size > 25 * 1024 * 1024) {
        setNotice(`${file.name} is empty or larger than the 25 MB limit.`);
        continue;
      }
      let fileId: string | undefined;
      try {
        const target = await requestUpload.mutateAsync({
          projectId,
          data: {
            name: file.name,
            size: file.size,
            contentType: file.type || 'application/octet-stream',
          },
        });
        fileId = target.fileId;
        const response = await fetch(target.uploadURL, {
          method: 'PUT',
          headers: { 'Content-Type': file.type || 'application/octet-stream' },
          body: file,
        });
        if (!response.ok) throw new Error('Storage upload failed.');
        await completeUpload.mutateAsync({ fileId });
        setNotice(`${file.name} uploaded.`);
        await client.invalidateQueries({ queryKey: getListProjectFilesQueryKey(projectId) });
      } catch {
        if (fileId) await deleteFile.mutateAsync({ fileId }).catch(() => undefined);
        setNotice(`Could not upload ${file.name}. Please try again.`);
      }
    }
    setUploading(false);
  }

  function removeFile(fileId: string, name: string) {
    if (!window.confirm(`Delete “${name}” from this project?`)) return;
    deleteFile.mutate({ fileId }, {
      onSuccess: () => {
        setNotice(`${name} deleted.`);
        void client.invalidateQueries({ queryKey: getListProjectFilesQueryKey(projectId) });
      },
      onError: () => setNotice(`Could not delete ${name}.`),
    });
  }

  return <section className="project-files" aria-label="Project files">
    <div className="project-files-heading"><span><FileText size={14} /> Files</span>{canUpload && <><input ref={inputRef} type="file" multiple hidden onChange={addFiles} data-testid={`input-project-files-${projectId}`} /><button type="button" onClick={() => inputRef.current?.click()} disabled={uploading} data-testid={`button-upload-project-file-${projectId}`}><Upload size={13} />{uploading ? 'Uploading…' : 'Add files'}</button></>}</div>
    {files.isLoading ? <span className="files-muted">Loading files…</span> : files.isError ? <div className="files-error">Files couldn’t load. <button onClick={() => void files.refetch()}>Retry</button></div> : !files.data?.length ? <span className="files-muted">No files added yet.</span> : <div className="project-file-list">{files.data.map(file => <div className="project-file-row" key={file.id}><FileText size={14} /><div><b>{file.name}</b><small>{formatFileSize(file.size)} · {dateLabel(file.uploadedAt)}</small></div><a href={getDownloadProjectFileUrl(file.id)} aria-label={`Download ${file.name}`} title={`Download ${file.name}`} data-testid={`link-download-file-${file.id}`}><Download size={14} /></a>{file.canDelete && <button type="button" aria-label={`Delete ${file.name}`} title={`Delete ${file.name}`} onClick={() => removeFile(file.id, file.name)} data-testid={`button-delete-file-${file.id}`}><Trash2 size={14} /></button>}</div>)}</div>}
    {notice && <span className="files-notice" role="status">{notice}</span>}
  </section>;
}

function formatFileSize(size: number) {
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(0)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

function PeopleSection({ workspace, members, membersQuery, invitations, invitationsQuery, openInvite, changeRole, removeMember, revokeInvite }: {
  workspace: Workspace; members?: WorkspaceMember[]; membersQuery: ReturnType<typeof useListMembers>;
  invitations?: { id: string; role: Role; createdAt: string; expiresAt: string }[]; invitationsQuery: ReturnType<typeof useListInvitations>;
  openInvite: () => void; changeRole: (member: WorkspaceMember, role: Role) => void; removeMember: (member: WorkspaceMember) => void; revokeInvite: (id: string) => void;
}) {
  return <div className="people-layout">
    <section className="people-panel panel"><div className="people-panel-head"><div><span className="eyebrow">The team</span><h2>Members <small>{members?.length ?? workspace.memberCount}</small></h2></div><button className="button-quiet" onClick={openInvite} data-testid="button-invite-member"><Plus size={14} /> Invite</button></div>
      {membersQuery.isLoading ? <div className="people-skeleton">{[1,2,3].map(i => <div className="skeleton" key={i} />)}</div> : membersQuery.isError ? <div className="inline-error">Members couldn’t load. <button onClick={() => void membersQuery.refetch()}>Try again</button></div> : !members?.length ? <EmptyState icon={Users} title="Your team starts here." detail="Invite the people who will make this work real." action={<button className="button-primary" onClick={openInvite}><Plus size={14} /> Invite a teammate</button>} /> : <div className="member-list">{members.map((member, i) => <div className="member-row" key={member.id} data-testid={`member-row-${member.id}`}><span className={`member-avatar avatar-${i % 4}`}>{member.userId.slice(-2).toUpperCase()}</span><div className="member-info"><b>{member.userId}</b><small>Joined {dateLabel(member.createdAt)}</small></div><select className="role-select" value={member.role} onChange={e => changeRole(member, e.target.value as Role)} aria-label={`Change role for ${member.userId}`} data-testid={`select-member-role-${member.id}`}><option value="OWNER">Owner</option>{roleOptions.map(r => <option key={r} value={r}>{roleLabel(r)}</option>)}</select><button className="remove-member" onClick={() => removeMember(member)} aria-label={`Remove ${member.userId}`} data-testid={`button-remove-member-${member.id}`}><X size={15} /></button></div>)}</div>}
    </section>
    <section className="people-panel panel"><div className="people-panel-head"><div><span className="eyebrow">Shared access</span><h2>Invitation links <small>{invitations?.length ?? 0}</small></h2></div><button className="icon-add" title="Create invitation" onClick={openInvite} aria-label="Create invitation" data-testid="button-add-invitation"><Plus size={16} /></button></div><div className="invite-security"><KeyRound size={15} /><p>Invitation links are bearer secrets. Anyone who has one can request to join before it expires or is revoked.</p></div>
      {invitationsQuery.isLoading ? <div className="people-skeleton">{[1,2].map(i => <div className="skeleton" key={i} />)}</div> : invitationsQuery.isError ? <div className="inline-error">Invitations couldn’t load. <button onClick={() => void invitationsQuery.refetch()}>Try again</button></div> : !invitations?.length ? <div className="invites-empty"><span>No active invitation links.</span><button onClick={openInvite}>Create one <ArrowRight size={13} /></button></div> : <div className="invitation-list">{invitations.map(invite => <div className="invitation-row" key={invite.id} data-testid={`invitation-row-${invite.id}`}><span className="invite-icon"><KeyRound size={15} /></span><span className="invite-info"><b>{roleLabel(invite.role)} access</b><small>Expires {dateLabel(invite.expiresAt)}</small></span><button className="revoke-button" onClick={() => revokeInvite(invite.id)} data-testid={`button-revoke-invite-${invite.id}`}>Revoke</button></div>)}</div>}
    </section>
  </div>;
}

function InvitePage() {
  const [, params] = useRoute('/invite/:token');
  const token = params?.token ?? '';
  const [, setLocation] = useLocation();
  const client = useQueryClient();
  const invite = useGetInvitation(token, { query: { enabled: !!token, queryKey: getGetInvitationQueryKey(token) } });
  const accept = useAcceptInvitation();
  const { isSignedIn } = useUser();
  if (invite.isLoading) return <InviteShell><div className="invite-preview-card"><div className="skeleton" style={{ width: 90, height: 12 }} /><div className="skeleton" style={{ width: '70%', height: 30, marginTop: 22 }} /><div className="skeleton" style={{ width: '100%', height: 70, marginTop: 28 }} /></div></InviteShell>;
  if (invite.isError || !invite.data) return <InviteShell><div className="invite-preview-card"><span className="invite-status-icon error"><X size={20} /></span><span className="eyebrow">Invitation unavailable</span><h1>This link can’t be used.</h1><p>It may have expired, been revoked, or already been accepted. Ask the workspace owner for a fresh invitation.</p><Link href="/" className="button-primary">Back to SmartwebAI <ArrowRight size={15} /></Link></div></InviteShell>;
  const invitation = invite.data;
  const expired = new Date(invitation.expiresAt).getTime() <= Date.now();
  return <InviteShell><div className="invite-preview-card"><span className="invite-status-icon"><Users size={21} /></span><span className="eyebrow">You’ve been invited</span><h1>Join {invitation.workspaceName}.</h1><p>You’ve been invited to collaborate in this SmartwebAI workspace.</p><div className="invite-role-box"><span>YOUR STARTING ROLE</span><b>{roleLabel(invitation.role)}</b><small>Invitation expires {dateLabel(invitation.expiresAt)}</small></div><div className="bearer-notice"><ShieldCheck size={15} /><p>This URL is a secret bearer link. Anyone with the link can request to join until it expires or is revoked. Keep it private.</p></div>{expired ? <div className="inline-error">This invitation has expired. Contact the workspace owner for a new link.</div> : isSignedIn ? <button className="button-primary invite-accept" disabled={accept.isPending} onClick={() => accept.mutate({ token }, { onSuccess: () => { void client.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); void client.invalidateQueries({ queryKey: getListWorkspacesQueryKey() }); setLocation('/user-portal'); }, onError: () => setLocation('/user-portal') })} data-testid="button-accept-invitation">{accept.isPending ? 'Joining workspace…' : 'Accept invitation'} <ArrowRight size={15} /></button> : <Link href={`/sign-in?redirect_url=${encodeURIComponent(`${basePath}/invite/${token}`)}`} className="button-primary invite-accept">Sign in to continue <ArrowRight size={15} /></Link>}<span className="invite-footnote"><LockKeyhole size={12} /> Secure collaboration, by design</span></div></InviteShell>;
}

function InviteShell({ children }: { children: ReactNode }) {
  return <div className="invite-page auth-background"><header className="invite-topbar"><Link href="/" className="landing-brand"><Mark /><span>smartweb<span className="brand-ai">AI</span></span></Link><Link href="/" className="button-quiet">Back to home</Link></header><main>{children}</main><footer>SmartwebAI <span>·</span> A focused workbench for collaborative projects.</footer></div>;
}

function UserPortal() {
  return <><Show when="signed-in"><WorkspacePortal /></Show><Show when="signed-out"><Redirect to="/" /></Show></>;
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const cache = useQueryClient();
  const previousUser = useRef<string | null | undefined>(undefined);
  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const id = user?.id ?? null;
      if (previousUser.current !== undefined && previousUser.current !== id) cache.clear();
      previousUser.current = id;
    });
    return unsubscribe;
  }, [addListener, cache]);
  return null;
}

function RoutedApp() {
  const [, setLocation] = useLocation();
  return <ClerkProvider publishableKey={clerkPubKey} proxyUrl={clerkProxyUrl} appearance={clerkAppearance} signInUrl={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} localization={{ signIn: { start: { title: 'Welcome back', subtitle: 'Sign in to return to your workspace' } }, signUp: { start: { title: 'Make room to build', subtitle: 'Create an account for your team workspace' } } }} routerPush={to => setLocation(stripBase(to))} routerReplace={to => setLocation(stripBase(to), { replace: true })}>
    <QueryClientProvider client={queryClient}>
      <ClerkQueryClientCacheInvalidator />
      <Switch>
        <Route path="/" component={HomeRedirect} />
        <Route path="/sign-in/*?" component={SignInPage} />
        <Route path="/sign-up/*?" component={SignUpPage} />
        <Route path="/user-portal" component={UserPortal} />
        <Route path="/invite/:token" component={InvitePage} />
        <Route component={NotFound} />
      </Switch>
    </QueryClientProvider>
  </ClerkProvider>;
}

function App() {
  if (!clerkPubKey) throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');
  return <WouterRouter base={basePath}><RoutedApp /></WouterRouter>;
}

export default App;

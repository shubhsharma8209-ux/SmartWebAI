import { createHash, randomBytes } from "node:crypto";
import {
  and,
  count,
  desc,
  eq,
  gt,
  inArray,
  isNull,
  sql,
} from "drizzle-orm";
import { Router, type IRouter, type Request, type Response } from "express";
import {
  AcceptInvitationParams,
  AcceptInvitationResponse,
  CreateInvitationBody,
  CreateInvitationParams,
  CreateInvitationResponse,
  CreateProjectBody,
  CreateProjectParams,
  CreateProjectResponse,
  CreateWorkspaceBody,
  CreateWorkspaceResponse,
  DeleteProjectParams,
  GetDashboardResponse,
  GetInvitationParams,
  GetInvitationResponse,
  ListInvitationsParams,
  ListInvitationsResponse,
  ListMembersParams,
  ListMembersResponse,
  ListProjectsParams,
  ListProjectsResponse,
  ListWorkspacesResponse,
  RemoveMemberParams,
  RevokeInvitationParams,
  UpdateMemberRoleBody,
  UpdateMemberRoleParams,
  UpdateMemberRoleResponse,
  UpdateProjectBody,
  UpdateProjectParams,
  UpdateProjectResponse,
} from "@workspace/api-zod";
import {
  db,
  projectFilesTable,
  projectsTable,
  workspaceInvitationsTable,
  workspaceMembersTable,
  workspacesTable,
} from "@workspace/db";
import type { WorkspaceRole } from "@workspace/db";
import {
  ObjectNotFoundError,
  ObjectStorageService,
} from "../lib/objectStorage";

const privateRouter: IRouter = Router();
const publicRouter: IRouter = Router();
const objectStorage = new ObjectStorageService();

type Role = WorkspaceRole;
type WorkspaceSummary = {
  id: string;
  name: string;
  createdAt: Date;
  role: Role;
  memberCount: number;
  projectCount: number;
};

function iso(date: Date): string {
  return date.toISOString();
}

function userIdFrom(req: Request): string {
  if (!req.userId) throw new Error("Authenticated user was not attached");
  return req.userId;
}

function tokenDigest(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

async function getRole(workspaceId: string, userId: string): Promise<Role | null> {
  const [membership] = await db
    .select({ role: workspaceMembersTable.role })
    .from(workspaceMembersTable)
    .where(
      and(
        eq(workspaceMembersTable.workspaceId, workspaceId),
        eq(workspaceMembersTable.userId, userId),
      ),
    )
    .limit(1);
  return membership?.role ?? null;
}

function canEditProjects(role: Role): boolean {
  return role !== "VIEWER";
}

function canManageMembers(role: Role): boolean {
  return role === "OWNER" || role === "ADMIN";
}

async function getWorkspaceSummaries(userId: string): Promise<WorkspaceSummary[]> {
  const rows = await db
    .select({
      id: workspacesTable.id,
      name: workspacesTable.name,
      createdAt: workspacesTable.createdAt,
      role: workspaceMembersTable.role,
    })
    .from(workspacesTable)
    .innerJoin(
      workspaceMembersTable,
      eq(workspaceMembersTable.workspaceId, workspacesTable.id),
    )
    .where(eq(workspaceMembersTable.userId, userId))
    .orderBy(desc(workspacesTable.createdAt));

  if (rows.length === 0) return [];
  const ids = rows.map((row) => row.id);
  const [projectCounts, memberCounts] = await Promise.all([
    db
      .select({
        workspaceId: projectsTable.workspaceId,
        total: sql<number>`count(*)::int`,
      })
      .from(projectsTable)
      .where(inArray(projectsTable.workspaceId, ids))
      .groupBy(projectsTable.workspaceId),
    db
      .select({
        workspaceId: workspaceMembersTable.workspaceId,
        total: sql<number>`count(*)::int`,
      })
      .from(workspaceMembersTable)
      .where(inArray(workspaceMembersTable.workspaceId, ids))
      .groupBy(workspaceMembersTable.workspaceId),
  ]);
  const projectCountByWorkspace = new Map(
    projectCounts.map((row) => [row.workspaceId, row.total]),
  );
  const memberCountByWorkspace = new Map(
    memberCounts.map((row) => [row.workspaceId, row.total]),
  );

  return rows.map((row) => ({
    ...row,
    memberCount: memberCountByWorkspace.get(row.id) ?? 0,
    projectCount: projectCountByWorkspace.get(row.id) ?? 0,
  }));
}

function workspaceResponse(workspace: WorkspaceSummary) {
  return {
    id: workspace.id,
    name: workspace.name,
    createdAt: iso(workspace.createdAt),
    role: workspace.role,
    memberCount: workspace.memberCount,
    projectCount: workspace.projectCount,
  };
}

function projectResponse(project: {
  id: string;
  workspaceId: string;
  name: string;
  isPrivate: boolean;
  createdAt: Date;
  updatedAt: Date;
}) {
  return {
    ...project,
    createdAt: iso(project.createdAt),
    updatedAt: iso(project.updatedAt),
  };
}

function memberResponse(member: {
  id: string;
  userId: string;
  role: Role;
  createdAt: Date;
}) {
  return { ...member, createdAt: iso(member.createdAt) };
}

function invitationResponse(invitation: {
  id: string;
  workspaceId: string;
  role: Role;
  createdAt: Date;
  expiresAt: Date;
}) {
  return {
    id: invitation.id,
    workspaceId: invitation.workspaceId,
    role: invitation.role,
    createdAt: iso(invitation.createdAt),
    expiresAt: iso(invitation.expiresAt),
  };
}

privateRouter.get("/dashboard", async (req, res): Promise<void> => {
  const userId = userIdFrom(req);
  const workspaces = await getWorkspaceSummaries(userId);
  const workspaceIds = workspaces.map((workspace) => workspace.id);

  if (workspaceIds.length === 0) {
    res.json(
      GetDashboardResponse.parse({
        workspaceCount: 0,
        projectCount: 0,
        memberCount: 0,
        recentProjects: [],
      }),
    );
    return;
  }

  const [projectCounts, members, recent] = await Promise.all([
    db
      .select({ total: count() })
      .from(projectsTable)
      .where(inArray(projectsTable.workspaceId, workspaceIds)),
    db
      .select({ total: count() })
      .from(workspaceMembersTable)
      .where(inArray(workspaceMembersTable.workspaceId, workspaceIds)),
    db
      .select()
      .from(projectsTable)
      .where(inArray(projectsTable.workspaceId, workspaceIds))
      .orderBy(desc(projectsTable.updatedAt))
      .limit(5),
  ]);

  res.json(
    GetDashboardResponse.parse({
      workspaceCount: workspaces.length,
      projectCount: projectCounts[0]?.total ?? 0,
      memberCount: members[0]?.total ?? 0,
      recentProjects: recent.map(projectResponse),
    }),
  );
});

privateRouter.get("/workspaces", async (req, res): Promise<void> => {
  const workspaces = await getWorkspaceSummaries(userIdFrom(req));
  res.json(ListWorkspacesResponse.parse(workspaces.map(workspaceResponse)));
});

privateRouter.post("/workspaces", async (req, res): Promise<void> => {
  const body = CreateWorkspaceBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const userId = userIdFrom(req);
  const result = await db.transaction(async (tx) => {
    const [workspace] = await tx
      .insert(workspacesTable)
      .values({ name: body.data.name.trim(), ownerUserId: userId })
      .returning();
    if (!workspace) throw new Error("Workspace creation failed");

    await tx.insert(workspaceMembersTable).values({
      workspaceId: workspace.id,
      userId,
      role: "OWNER",
    });
    return workspace;
  });

  res.status(201).json(
    CreateWorkspaceResponse.parse({
      id: result.id,
      name: result.name,
      createdAt: iso(result.createdAt),
      role: "OWNER",
      memberCount: 1,
      projectCount: 0,
    }),
  );
});

privateRouter.get(
  "/workspaces/:workspaceId/projects",
  async (req, res): Promise<void> => {
    const params = ListProjectsParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    if (!(await getRole(params.data.workspaceId, userIdFrom(req)))) {
      res.status(404).json({ error: "Workspace not found." });
      return;
    }
    const projects = await db
      .select()
      .from(projectsTable)
      .where(eq(projectsTable.workspaceId, params.data.workspaceId))
      .orderBy(desc(projectsTable.updatedAt));
    res.json(ListProjectsResponse.parse(projects.map(projectResponse)));
  },
);

privateRouter.post(
  "/workspaces/:workspaceId/projects",
  async (req, res): Promise<void> => {
    const params = CreateProjectParams.safeParse(req.params);
    const body = CreateProjectBody.safeParse(req.body);
    if (!params.success || !body.success) {
      res.status(400).json({
        error: !params.success
          ? params.error.message
          : !body.success
            ? body.error.message
            : "Invalid project.",
      });
      return;
    }
    const role = await getRole(params.data.workspaceId, userIdFrom(req));
    if (!role) {
      res.status(404).json({ error: "Workspace not found." });
      return;
    }
    if (!canEditProjects(role)) {
      res.status(403).json({ error: "Your workspace role is read-only." });
      return;
    }
    const [project] = await db
      .insert(projectsTable)
      .values({
        workspaceId: params.data.workspaceId,
        name: body.data.name.trim(),
        isPrivate: body.data.isPrivate,
      })
      .returning();
    if (!project) {
      res.status(500).json({ error: "Project could not be created." });
      return;
    }
    res.status(201).json(CreateProjectResponse.parse(projectResponse(project)));
  },
);

privateRouter.patch(
  "/projects/:projectId",
  async (req, res): Promise<void> => {
    const params = UpdateProjectParams.safeParse(req.params);
    const body = UpdateProjectBody.safeParse(req.body);
    if (!params.success || !body.success || Object.keys(body.data ?? {}).length === 0) {
      res.status(400).json({
        error: !params.success
          ? params.error.message
          : !body.success
            ? body.error.message
            : "Provide at least one field to update.",
      });
      return;
    }
    const [existing] = await db
      .select()
      .from(projectsTable)
      .where(eq(projectsTable.id, params.data.projectId))
      .limit(1);
    if (!existing) {
      res.status(404).json({ error: "Project not found." });
      return;
    }
    const role = await getRole(existing.workspaceId, userIdFrom(req));
    if (!role) {
      res.status(404).json({ error: "Project not found." });
      return;
    }
    if (!canEditProjects(role)) {
      res.status(403).json({ error: "Your workspace role is read-only." });
      return;
    }
    const [updated] = await db
      .update(projectsTable)
      .set({
        ...body.data,
        ...(body.data.name ? { name: body.data.name.trim() } : {}),
        updatedAt: new Date(),
      })
      .where(eq(projectsTable.id, params.data.projectId))
      .returning();
    if (!updated) {
      res.status(404).json({ error: "Project not found." });
      return;
    }
    res.json(UpdateProjectResponse.parse(projectResponse(updated)));
  },
);

privateRouter.delete(
  "/projects/:projectId",
  async (req, res): Promise<void> => {
    const params = DeleteProjectParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const [project] = await db
      .select()
      .from(projectsTable)
      .where(eq(projectsTable.id, params.data.projectId))
      .limit(1);
    if (!project) {
      res.status(404).json({ error: "Project not found." });
      return;
    }
    const role = await getRole(project.workspaceId, userIdFrom(req));
    if (!role) {
      res.status(404).json({ error: "Project not found." });
      return;
    }
    if (role !== "OWNER" && role !== "ADMIN") {
      res.status(403).json({ error: "Only workspace admins can delete projects." });
      return;
    }
    const projectFiles = await db
      .select({ objectPath: projectFilesTable.objectPath })
      .from(projectFilesTable)
      .where(eq(projectFilesTable.projectId, project.id));
    try {
      for (const file of projectFiles) {
        await objectStorage.deleteObjectEntity(file.objectPath).catch((error) => {
          if (!(error instanceof ObjectNotFoundError)) throw error;
        });
      }
    } catch {
      res.status(500).json({
        error: "Project files could not be removed from storage. The project was kept.",
      });
      return;
    }
    await db.delete(projectsTable).where(eq(projectsTable.id, project.id));
    res.sendStatus(204);
  },
);

privateRouter.get(
  "/workspaces/:workspaceId/members",
  async (req, res): Promise<void> => {
    const params = ListMembersParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    if (!(await getRole(params.data.workspaceId, userIdFrom(req)))) {
      res.status(404).json({ error: "Workspace not found." });
      return;
    }
    const members = await db
      .select({
        id: workspaceMembersTable.id,
        userId: workspaceMembersTable.userId,
        role: workspaceMembersTable.role,
        createdAt: workspaceMembersTable.createdAt,
      })
      .from(workspaceMembersTable)
      .where(eq(workspaceMembersTable.workspaceId, params.data.workspaceId))
      .orderBy(workspaceMembersTable.createdAt);
    res.json(ListMembersResponse.parse(members.map(memberResponse)));
  },
);

privateRouter.patch(
  "/workspaces/:workspaceId/members/:memberId",
  async (req, res): Promise<void> => {
    const params = UpdateMemberRoleParams.safeParse(req.params);
    const body = UpdateMemberRoleBody.safeParse(req.body);
    if (!params.success || !body.success) {
      res.status(400).json({
        error: !params.success
          ? params.error.message
          : !body.success
            ? body.error.message
            : "Invalid role.",
      });
      return;
    }
    const actorId = userIdFrom(req);
    const actorRole = await getRole(params.data.workspaceId, actorId);
    if (!actorRole) {
      res.status(404).json({ error: "Workspace not found." });
      return;
    }
    const [target] = await db
      .select()
      .from(workspaceMembersTable)
      .where(
        and(
          eq(workspaceMembersTable.id, params.data.memberId),
          eq(workspaceMembersTable.workspaceId, params.data.workspaceId),
        ),
      )
      .limit(1);
    if (!target) {
      res.status(404).json({ error: "Member not found." });
      return;
    }
    if (
      !canManageMembers(actorRole) ||
      target.role === "OWNER" ||
      body.data.role === "OWNER" ||
      (actorRole === "ADMIN" &&
        (target.role === "ADMIN" || body.data.role === "ADMIN"))
    ) {
      res.status(403).json({ error: "You cannot change this member's role." });
      return;
    }
    const [updated] = await db
      .update(workspaceMembersTable)
      .set({ role: body.data.role })
      .where(eq(workspaceMembersTable.id, target.id))
      .returning();
    if (!updated) {
      res.status(404).json({ error: "Member not found." });
      return;
    }
    res.json(UpdateMemberRoleResponse.parse(memberResponse(updated)));
  },
);

privateRouter.delete(
  "/workspaces/:workspaceId/members/:memberId",
  async (req, res): Promise<void> => {
    const params = RemoveMemberParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const actorId = userIdFrom(req);
    const actorRole = await getRole(params.data.workspaceId, actorId);
    if (!actorRole) {
      res.status(404).json({ error: "Workspace not found." });
      return;
    }
    const [target] = await db
      .select()
      .from(workspaceMembersTable)
      .where(
        and(
          eq(workspaceMembersTable.id, params.data.memberId),
          eq(workspaceMembersTable.workspaceId, params.data.workspaceId),
        ),
      )
      .limit(1);
    if (!target) {
      res.status(404).json({ error: "Member not found." });
      return;
    }
    const isSelf = target.userId === actorId;
    const isOwner = target.role === "OWNER";
    const permitted =
      !isOwner &&
      ((actorRole === "OWNER" && !isSelf) ||
        (actorRole === "ADMIN" &&
          !isSelf &&
          target.role !== "ADMIN") ||
        (isSelf && actorRole !== "OWNER"));
    if (!permitted) {
      res.status(403).json({ error: "You cannot remove this workspace member." });
      return;
    }
    await db
      .delete(workspaceMembersTable)
      .where(eq(workspaceMembersTable.id, target.id));
    res.sendStatus(204);
  },
);

privateRouter.get(
  "/workspaces/:workspaceId/invitations",
  async (req, res): Promise<void> => {
    const params = ListInvitationsParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const role = await getRole(params.data.workspaceId, userIdFrom(req));
    if (!role) {
      res.status(404).json({ error: "Workspace not found." });
      return;
    }
    if (!canManageMembers(role)) {
      res.status(403).json({ error: "Only workspace admins can manage invitations." });
      return;
    }
    const now = new Date();
    const invitations = await db
      .select({
        id: workspaceInvitationsTable.id,
        workspaceId: workspaceInvitationsTable.workspaceId,
        role: workspaceInvitationsTable.role,
        createdAt: workspaceInvitationsTable.createdAt,
        expiresAt: workspaceInvitationsTable.expiresAt,
      })
      .from(workspaceInvitationsTable)
      .where(
        and(
          eq(workspaceInvitationsTable.workspaceId, params.data.workspaceId),
          isNull(workspaceInvitationsTable.revokedAt),
          isNull(workspaceInvitationsTable.acceptedAt),
          gt(workspaceInvitationsTable.expiresAt, now),
        ),
      )
      .orderBy(desc(workspaceInvitationsTable.createdAt));
    res.json(ListInvitationsResponse.parse(invitations.map(invitationResponse)));
  },
);

privateRouter.post(
  "/workspaces/:workspaceId/invitations",
  async (req, res): Promise<void> => {
    const params = CreateInvitationParams.safeParse(req.params);
    const body = CreateInvitationBody.safeParse(req.body);
    if (!params.success || !body.success) {
      res.status(400).json({
        error: !params.success
          ? params.error.message
          : !body.success
            ? body.error.message
            : "Invalid invitation.",
      });
      return;
    }
    const actorRole = await getRole(params.data.workspaceId, userIdFrom(req));
    if (!actorRole) {
      res.status(404).json({ error: "Workspace not found." });
      return;
    }
    if (
      !canManageMembers(actorRole) ||
      body.data.role === "OWNER" ||
      (actorRole === "ADMIN" && body.data.role === "ADMIN")
    ) {
      res.status(403).json({ error: "You cannot create an invitation for this role." });
      return;
    }
    const token = randomBytes(32).toString("base64url");
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    const [invitation] = await db
      .insert(workspaceInvitationsTable)
      .values({
        workspaceId: params.data.workspaceId,
        tokenHash: tokenDigest(token),
        role: body.data.role,
        createdBy: userIdFrom(req),
        expiresAt,
      })
      .returning({
        id: workspaceInvitationsTable.id,
        workspaceId: workspaceInvitationsTable.workspaceId,
        role: workspaceInvitationsTable.role,
        createdAt: workspaceInvitationsTable.createdAt,
        expiresAt: workspaceInvitationsTable.expiresAt,
      });
    if (!invitation) {
      res.status(500).json({ error: "Invitation could not be created." });
      return;
    }
    res.status(201).json(
      CreateInvitationResponse.parse({ ...invitationResponse(invitation), token }),
    );
  },
);

privateRouter.delete(
  "/workspaces/:workspaceId/invitations/:invitationId",
  async (req, res): Promise<void> => {
    const params = RevokeInvitationParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const role = await getRole(params.data.workspaceId, userIdFrom(req));
    if (!role) {
      res.status(404).json({ error: "Workspace not found." });
      return;
    }
    if (!canManageMembers(role)) {
      res.status(403).json({ error: "Only workspace admins can revoke invitations." });
      return;
    }
    const [revoked] = await db
      .update(workspaceInvitationsTable)
      .set({ revokedAt: new Date() })
      .where(
        and(
          eq(workspaceInvitationsTable.id, params.data.invitationId),
          eq(workspaceInvitationsTable.workspaceId, params.data.workspaceId),
          isNull(workspaceInvitationsTable.revokedAt),
          isNull(workspaceInvitationsTable.acceptedAt),
        ),
      )
      .returning({ id: workspaceInvitationsTable.id });
    if (!revoked) {
      res.status(404).json({ error: "Invitation not found." });
      return;
    }
    res.sendStatus(204);
  },
);

publicRouter.get(
  "/invitations/:token",
  async (req: Request, res: Response): Promise<void> => {
    const params = GetInvitationParams.safeParse(req.params);
    if (!params.success) {
      res.status(404).json({ error: "Invitation is invalid or expired." });
      return;
    }
    const [record] = await db
      .select({
        workspaceId: workspacesTable.id,
        workspaceName: workspacesTable.name,
        role: workspaceInvitationsTable.role,
        expiresAt: workspaceInvitationsTable.expiresAt,
      })
      .from(workspaceInvitationsTable)
      .innerJoin(
        workspacesTable,
        eq(workspacesTable.id, workspaceInvitationsTable.workspaceId),
      )
      .where(
        and(
          eq(
            workspaceInvitationsTable.tokenHash,
            tokenDigest(params.data.token),
          ),
          isNull(workspaceInvitationsTable.revokedAt),
          isNull(workspaceInvitationsTable.acceptedAt),
          gt(workspaceInvitationsTable.expiresAt, new Date()),
        ),
      )
      .limit(1);
    if (!record) {
      res.status(404).json({ error: "Invitation is invalid or expired." });
      return;
    }
    res.json(
      GetInvitationResponse.parse({
        ...record,
        expiresAt: iso(record.expiresAt),
      }),
    );
  },
);

privateRouter.post(
  "/invitations/:token/accept",
  async (req, res): Promise<void> => {
    const params = AcceptInvitationParams.safeParse(req.params);
    if (!params.success) {
      res.status(404).json({ error: "Invitation is invalid or expired." });
      return;
    }
    const userId = userIdFrom(req);
    const digest = tokenDigest(params.data.token);
    const workspaceId = await db.transaction(async (tx) => {
      const [invitation] = await tx
        .select()
        .from(workspaceInvitationsTable)
        .where(
          and(
            eq(workspaceInvitationsTable.tokenHash, digest),
            isNull(workspaceInvitationsTable.revokedAt),
            isNull(workspaceInvitationsTable.acceptedAt),
            gt(workspaceInvitationsTable.expiresAt, new Date()),
          ),
        )
        .limit(1)
        .for("update");
      if (!invitation) return null;
      await tx
        .insert(workspaceMembersTable)
        .values({
          workspaceId: invitation.workspaceId,
          userId,
          role: invitation.role,
        })
        .onConflictDoNothing();
      await tx
        .update(workspaceInvitationsTable)
        .set({ acceptedAt: new Date() })
        .where(eq(workspaceInvitationsTable.id, invitation.id));
      return invitation.workspaceId;
    });
    if (!workspaceId) {
      res.status(404).json({ error: "Invitation is invalid or expired." });
      return;
    }
    const workspaces = await getWorkspaceSummaries(userId);
    const workspace = workspaces.find((item) => item.id === workspaceId);
    if (!workspace) {
      res.status(500).json({ error: "Workspace membership could not be confirmed." });
      return;
    }
    res.json(AcceptInvitationResponse.parse(workspaceResponse(workspace)));
  },
);

export const publicInvitationRouter = publicRouter;
export const privateWorkspaceRouter = privateRouter;

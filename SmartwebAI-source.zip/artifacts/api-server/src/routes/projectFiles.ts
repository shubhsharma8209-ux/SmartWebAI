import { basename } from "node:path";
import { Readable } from "node:stream";
import {
  and,
  desc,
  eq,
  gt,
  isNotNull,
  isNull,
} from "drizzle-orm";
import { Router, type IRouter, type Request, type Response } from "express";
import {
  CompleteProjectFileUploadParams,
  CompleteProjectFileUploadResponse,
  DeleteProjectFileParams,
  DownloadProjectFileParams,
  ListProjectFilesParams,
  ListProjectFilesResponse,
  RequestProjectFileUploadBody,
  RequestProjectFileUploadParams,
  RequestProjectFileUploadResponse,
} from "@workspace/api-zod";
import {
  db,
  projectFilesTable,
  projectsTable,
  workspaceMembersTable,
} from "@workspace/db";
import type { ProjectFile, WorkspaceRole } from "@workspace/db";
import {
  ObjectNotFoundError,
  ObjectStorageService,
} from "../lib/objectStorage";

const router: IRouter = Router();
const objectStorage = new ObjectStorageService();
const MAX_UPLOAD_BYTES = 25 * 1024 * 1024;
const UPLOAD_TTL_MS = 15 * 60 * 1000;

function fileResponse(file: ProjectFile, canDelete: boolean) {
  if (!file.uploadedAt) throw new Error("Pending uploads cannot be returned.");
  return {
    id: file.id,
    projectId: file.projectId,
    name: file.name,
    size: file.size,
    contentType: file.contentType,
    createdAt: file.createdAt.toISOString(),
    uploadedAt: file.uploadedAt.toISOString(),
    canDelete,
  };
}

function currentUserId(req: Request): string {
  if (!req.userId) throw new Error("Authenticated user was not attached");
  return req.userId;
}

async function projectRole(
  projectId: string,
  userId: string,
): Promise<{ workspaceId: string; role: WorkspaceRole } | null> {
  const [project] = await db
    .select({ workspaceId: projectsTable.workspaceId })
    .from(projectsTable)
    .where(eq(projectsTable.id, projectId))
    .limit(1);
  if (!project) return null;

  const [membership] = await db
    .select({ role: workspaceMembersTable.role })
    .from(workspaceMembersTable)
    .where(
      and(
        eq(workspaceMembersTable.workspaceId, project.workspaceId),
        eq(workspaceMembersTable.userId, userId),
      ),
    )
    .limit(1);
  if (!membership) return null;
  return { workspaceId: project.workspaceId, role: membership.role };
}

function cleanFileName(value: string): string {
  const name = basename(value.replace(/\\/g, "/"))
    .replace(/[\u0000-\u001f\u007f]/g, "")
    .trim()
    .slice(0, 255);
  return name;
}

function sendPrivateDownload(
  response: Response,
  file: ProjectFile,
  body: ReadableStream<Uint8Array> | null,
): void {
  response.status(200);
  response.setHeader("Content-Type", "application/octet-stream");
  response.setHeader("X-Content-Type-Options", "nosniff");
  response.setHeader(
    "Content-Disposition",
    `attachment; filename*=UTF-8''${encodeURIComponent(file.name)}`,
  );
  response.setHeader("Cache-Control", "private, no-store");
  if (!body) {
    response.end();
    return;
  }
  const stream = Readable.fromWeb(body);
  stream.on("error", () => {
    if (response.headersSent) response.destroy();
    else response.status(500).end();
  });
  stream.pipe(response);
}

router.get(
  "/projects/:projectId/files",
  async (req: Request, res: Response): Promise<void> => {
    const params = ListProjectFilesParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const userId = currentUserId(req);
    const access = await projectRole(params.data.projectId, userId);
    if (!access) {
      res.status(404).json({ error: "Project not found." });
      return;
    }
    const files = await db
      .select()
      .from(projectFilesTable)
      .where(
        and(
          eq(projectFilesTable.projectId, params.data.projectId),
          isNotNull(projectFilesTable.uploadedAt),
        ),
      )
      .orderBy(desc(projectFilesTable.createdAt));
    res.json(
      ListProjectFilesResponse.parse(
        files.map((file) =>
          fileResponse(
            file,
            file.uploadedBy === userId ||
              access.role === "OWNER" ||
              access.role === "ADMIN",
          ),
        ),
      ),
    );
  },
);

router.post(
  "/projects/:projectId/files",
  async (req: Request, res: Response): Promise<void> => {
    const params = RequestProjectFileUploadParams.safeParse(req.params);
    const body = RequestProjectFileUploadBody.safeParse(req.body);
    if (!params.success || !body.success) {
      res.status(400).json({
        error: !params.success
          ? params.error.message
          : !body.success
            ? body.error.message
            : "Invalid file upload.",
      });
      return;
    }
    const userId = currentUserId(req);
    const access = await projectRole(params.data.projectId, userId);
    if (!access) {
      res.status(404).json({ error: "Project not found." });
      return;
    }
    if (access.role === "VIEWER") {
      res.status(403).json({ error: "Your workspace role cannot upload files." });
      return;
    }
    const name = cleanFileName(body.data.name);
    const contentType = body.data.contentType.trim().slice(0, 255);
    if (!name || body.data.size > MAX_UPLOAD_BYTES || !contentType) {
      res.status(400).json({
        error: "Choose a named file up to 25 MB with a content type.",
      });
      return;
    }

    const uploadURL = await objectStorage.getObjectEntityUploadURL();
    const objectPath = objectStorage.normalizeObjectEntityPath(uploadURL);
    if (!objectPath.startsWith("/objects/uploads/")) {
      throw new Error("Object storage returned an invalid private object path.");
    }
    const uploadExpiresAt = new Date(Date.now() + UPLOAD_TTL_MS);
    const [pending] = await db
      .insert(projectFilesTable)
      .values({
        projectId: params.data.projectId,
        name,
        objectPath,
        size: body.data.size,
        contentType,
        uploadedBy: userId,
        uploadExpiresAt,
      })
      .returning({ id: projectFilesTable.id });
    if (!pending) {
      res.status(500).json({ error: "File upload could not be started." });
      return;
    }
    res.status(201).json(
      RequestProjectFileUploadResponse.parse({
        fileId: pending.id,
        uploadURL,
        uploadExpiresAt: uploadExpiresAt.toISOString(),
      }),
    );
  },
);

router.post(
  "/files/:fileId/complete",
  async (req: Request, res: Response): Promise<void> => {
    const params = CompleteProjectFileUploadParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const [file] = await db
      .select()
      .from(projectFilesTable)
      .where(eq(projectFilesTable.id, params.data.fileId))
      .limit(1);
    if (!file) {
      res.status(404).json({ error: "Upload not found or expired." });
      return;
    }
    const userId = currentUserId(req);
    const access = await projectRole(file.projectId, userId);
    if (!access) {
      res.status(404).json({ error: "Upload not found or expired." });
      return;
    }
    if (
      file.uploadedBy !== userId &&
      access.role !== "OWNER" &&
      access.role !== "ADMIN"
    ) {
      res.status(403).json({ error: "You cannot complete this file upload." });
      return;
    }
    if (file.uploadedAt) {
      res.json(
        CompleteProjectFileUploadResponse.parse(
          fileResponse(
            file,
            file.uploadedBy === userId ||
              access.role === "OWNER" ||
              access.role === "ADMIN",
          ),
        ),
      );
      return;
    }
    if (file.uploadExpiresAt <= new Date()) {
      await objectStorage.deleteObjectEntity(file.objectPath).catch((error) => {
        if (!(error instanceof ObjectNotFoundError)) throw error;
      });
      await db.delete(projectFilesTable).where(eq(projectFilesTable.id, file.id));
      res.status(404).json({ error: "Upload not found or expired." });
      return;
    }

    let storedObject;
    try {
      storedObject = await objectStorage.getObjectEntityFile(file.objectPath);
      const [metadata] = await storedObject.getMetadata();
      const actualSize = Number(metadata.size);
      if (
        !Number.isSafeInteger(actualSize) ||
        actualSize !== file.size ||
        actualSize > MAX_UPLOAD_BYTES
      ) {
        await storedObject.delete().catch(() => undefined);
        await db.delete(projectFilesTable).where(eq(projectFilesTable.id, file.id));
        res.status(400).json({ error: "Uploaded file size did not match its request." });
        return;
      }
    } catch (error) {
      if (error instanceof ObjectNotFoundError) {
        res.status(400).json({ error: "Upload is not present in storage yet." });
        return;
      }
      throw error;
    }

    const [completed] = await db
      .update(projectFilesTable)
      .set({ uploadedAt: new Date() })
      .where(
        and(
          eq(projectFilesTable.id, file.id),
          isNull(projectFilesTable.uploadedAt),
          gt(projectFilesTable.uploadExpiresAt, new Date()),
        ),
      )
      .returning();
    const result = completed ?? file;
    res.json(
      CompleteProjectFileUploadResponse.parse({
        ...fileResponse({
          ...result,
          uploadedAt: result.uploadedAt ?? new Date(),
        }, file.uploadedBy === userId || access.role === "OWNER" || access.role === "ADMIN"),
      }),
    );
  },
);

router.get(
  "/files/:fileId/content",
  async (req: Request, res: Response): Promise<void> => {
    const params = DownloadProjectFileParams.safeParse(req.params);
    if (!params.success) {
      res.status(404).json({ error: "File not found." });
      return;
    }
    const [file] = await db
      .select()
      .from(projectFilesTable)
      .where(
        and(
          eq(projectFilesTable.id, params.data.fileId),
          isNotNull(projectFilesTable.uploadedAt),
        ),
      )
      .limit(1);
    if (!file || !(await projectRole(file.projectId, currentUserId(req)))) {
      res.status(404).json({ error: "File not found." });
      return;
    }
    try {
      const storedObject = await objectStorage.getObjectEntityFile(file.objectPath);
      const downloaded = await objectStorage.downloadObject(storedObject);
      sendPrivateDownload(res, file, downloaded.body);
    } catch (error) {
      if (error instanceof ObjectNotFoundError) {
        res.status(404).json({ error: "File not found." });
        return;
      }
      throw error;
    }
  },
);

router.delete(
  "/files/:fileId",
  async (req: Request, res: Response): Promise<void> => {
    const params = DeleteProjectFileParams.safeParse(req.params);
    if (!params.success) {
      res.status(404).json({ error: "File not found." });
      return;
    }
    const [file] = await db
      .select()
      .from(projectFilesTable)
      .where(eq(projectFilesTable.id, params.data.fileId))
      .limit(1);
    if (!file || !(await projectRole(file.projectId, currentUserId(req)))) {
      res.status(404).json({ error: "File not found." });
      return;
    }
    const userId = currentUserId(req);
    const access = await projectRole(file.projectId, userId);
    if (
      !access ||
      (file.uploadedBy !== userId &&
        access.role !== "OWNER" &&
        access.role !== "ADMIN")
    ) {
      res.status(403).json({ error: "You cannot delete this file." });
      return;
    }
    try {
      await objectStorage.deleteObjectEntity(file.objectPath);
    } catch (error) {
      if (!(error instanceof ObjectNotFoundError)) throw error;
    }
    await db.delete(projectFilesTable).where(eq(projectFilesTable.id, file.id));
    res.sendStatus(204);
  },
);

export default router;

import { Router, type IRouter } from "express";
import healthRouter from "./health";
import { requireAuth } from "../middlewares/requireAuth";
import {
  privateWorkspaceRouter,
  publicInvitationRouter,
} from "./workspaces";
import projectFilesRouter from "./projectFiles";

const router: IRouter = Router();

router.use(healthRouter);
router.use(publicInvitationRouter);
router.use(requireAuth);
router.use(privateWorkspaceRouter);
router.use(projectFilesRouter);

export default router;

import { createInsertSchema } from "drizzle-zod";
import {
  boolean,
  index,
  integer,
  pgEnum,
  pgTable,
  text,
  timestamp,
  unique,
  uuid,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const workspaceRoleEnum = pgEnum("workspace_role", [
  "OWNER",
  "ADMIN",
  "DEVELOPER",
  "DESIGNER",
  "CONTRIBUTOR",
  "VIEWER",
]);
export type WorkspaceRole = (typeof workspaceRoleEnum.enumValues)[number];

export const workspacesTable = pgTable("workspaces", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  ownerUserId: text("owner_user_id").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const insertWorkspaceSchema = createInsertSchema(workspacesTable, {
  name: z.string().trim().min(1).max(80),
}).omit({
  id: true,
  createdAt: true,
});
export type InsertWorkspace = z.infer<typeof insertWorkspaceSchema>;
export type Workspace = typeof workspacesTable.$inferSelect;

export const workspaceMembersTable = pgTable(
  "workspace_members",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspacesTable.id, { onDelete: "cascade" }),
    userId: text("user_id").notNull(),
    role: workspaceRoleEnum("role").notNull().default("VIEWER"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [unique("workspace_members_user_workspace_unique").on(table.userId, table.workspaceId)],
);

export const insertWorkspaceMemberSchema = createInsertSchema(
  workspaceMembersTable,
).omit({
  id: true,
  createdAt: true,
});
export type InsertWorkspaceMember = z.infer<
  typeof insertWorkspaceMemberSchema
>;
export type WorkspaceMember = typeof workspaceMembersTable.$inferSelect;

export const projectsTable = pgTable("projects", {
  id: uuid("id").defaultRandom().primaryKey(),
  workspaceId: uuid("workspace_id")
    .notNull()
    .references(() => workspacesTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  isPrivate: boolean("is_private").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const insertProjectSchema = createInsertSchema(projectsTable, {
  name: z.string().trim().min(1).max(100),
}).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projectsTable.$inferSelect;

export const workspaceInvitationsTable = pgTable("workspace_invitations", {
  id: uuid("id").defaultRandom().primaryKey(),
  workspaceId: uuid("workspace_id")
    .notNull()
    .references(() => workspacesTable.id, { onDelete: "cascade" }),
  tokenHash: text("token_hash").notNull().unique(),
  role: workspaceRoleEnum("role").notNull().default("VIEWER"),
  createdBy: text("created_by").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  revokedAt: timestamp("revoked_at", { withTimezone: true }),
  acceptedAt: timestamp("accepted_at", { withTimezone: true }),
});

export const insertWorkspaceInvitationSchema = createInsertSchema(
  workspaceInvitationsTable,
).omit({
  id: true,
  createdAt: true,
  revokedAt: true,
  acceptedAt: true,
});
export type InsertWorkspaceInvitation = z.infer<
  typeof insertWorkspaceInvitationSchema
>;
export type WorkspaceInvitation =
  typeof workspaceInvitationsTable.$inferSelect;

export const projectFilesTable = pgTable(
  "project_files",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    projectId: uuid("project_id")
      .notNull()
      .references(() => projectsTable.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    objectPath: text("object_path").notNull().unique(),
    size: integer("size").notNull(),
    contentType: text("content_type").notNull(),
    uploadedBy: text("uploaded_by").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    uploadExpiresAt: timestamp("upload_expires_at", {
      withTimezone: true,
    }).notNull(),
    uploadedAt: timestamp("uploaded_at", { withTimezone: true }),
  },
  (table) => [index("project_files_project_id_idx").on(table.projectId)],
);
export type ProjectFile = typeof projectFilesTable.$inferSelect;
